---
name: Proposals
about: New external API or other notable changes
title: "proposal: affected/package: "
labels: Proposal
---

<!--
Our proposal process is documented here:
https://go.dev/s/proposal-process
-->


