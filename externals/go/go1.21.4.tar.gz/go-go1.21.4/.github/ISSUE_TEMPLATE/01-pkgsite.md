---
name: Pkg.go.dev bugs or feature requests
about: Issues or feature requests for the documentation site
title: "x/pkgsite: "
labels: pkgsite
---

<!--
Please answer these questions before submitting your issue. Thanks!
-->

### What is the URL of the page with the issue?



### What is your user agent?

<!--
You can find your user agent here:
https://www.google.com/search?q=what+is+my+user+agent
-->



### Screenshot

<!--
Please paste a screenshot of the page.
-->



### What did you do?

<!--
If possible, provide a recipe for reproducing the error.

Starting with a Private/Incognito tab/window may help rule out problematic browser extensions.
-->



### What did you expect to see?



### What did you see instead?


